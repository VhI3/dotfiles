### [Mutt](http://www.mutt.org)

#### Install using Git

If you are a git user, you can install the theme and keep up to date by cloning the repo:

    git clone https://github.com/dracula/mutt.git

#### Install manually

Download using the [GitHub .zip download](https://github.com/dracula/mutt/archive/master.zip) option and unzip them.

#### Activating theme

Move `dracula.muttrc` into `~/.mutt/` and add the following to your muttrc file:

    source ~/.mutt/dracula.muttrc

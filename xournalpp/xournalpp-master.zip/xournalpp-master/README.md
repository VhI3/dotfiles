# Dracula for [Xournal++](https://xournalpp.github.io)

> A dark theme for [Xournal++](https://xournalpp.github.io).

![Screenshot](./screenshot.png)

## Install

All instructions can be found at [draculatheme.com/xournalpp](https://draculatheme.com/xournalpp).

## Team

This theme is maintained by the following person(s) and a bunch of [awesome contributors](https://github.com/dracula/xournalpp/graphs/contributors).

[![Tim Clifford](https://github.com/tim-clifford.png?size=100)](https://github.com/tim-clifford) |
--- |
[Tim Clifford](https://github.com/tim-clifford) |

## License

[MIT License](./LICENSE)

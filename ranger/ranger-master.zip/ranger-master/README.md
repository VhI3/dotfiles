# Dracula for [ranger](https://github.com/ranger/ranger)

> A dark theme for [ranger](https://github.com/ranger/ranger).

![Screenshot](./screenshot.png)

## Install

All instructions can be found at [draculatheme.com/ranger](https://draculatheme.com/ranger).

## Team

This theme is maintained by the following person(s) and a bunch of [awesome contributors](https://github.com/dracula/ranger/graphs/contributors).

[![Thales Nunes](https://github.com/thalesnunes.png?size=100)](https://github.com/thalesnunes) |
--- |
[Thales Nunes](https://github.com/thalesnunes) |

## License

[MIT License](./LICENSE)
